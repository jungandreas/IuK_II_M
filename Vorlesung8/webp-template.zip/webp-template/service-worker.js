"use strict";

self.addEventListener('fetch', function(event) {

});