"use strict";

this.addEventListener('fetch', function (event) {
  // TODO
});